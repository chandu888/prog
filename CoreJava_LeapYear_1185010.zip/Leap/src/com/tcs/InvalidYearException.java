package com.tcs;

@SuppressWarnings("serial")
public class InvalidYearException extends Exception {
	
	InvalidYearException()
	{  
	      super();  
	}
}
