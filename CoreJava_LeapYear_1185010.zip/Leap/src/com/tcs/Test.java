package com.tcs;

import java.util.InputMismatchException;

public class Test {

	
	public static void main(String[] args) {
		
			 Leap leapy=new Leap();
			 
		      try
		      {
		        leapy.findLeapYear() ;
		      }
		      
		      catch(InputMismatchException | InvalidYearException e) 
		      {
		        System.out.println(" please enter correct input "); 
		      }
		     
		      finally
		      {
		        System.out.println(" finally is executed "); 
		      }
	}
}
