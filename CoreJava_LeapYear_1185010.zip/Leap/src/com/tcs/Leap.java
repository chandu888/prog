package com.tcs;

import java.util.Scanner;

public class Leap {
	public void findLeapYear() throws InvalidYearException {

	       System.out.println("please enter the year: ");
	       Scanner scan=new Scanner(System.in);
	       int year=scan.nextInt();

	        if(year<=0) 
	          throw new InvalidYearException();
	        else if((year%400==0)||((year%4==0)&&(year%100!=0)))
	          System.out.println("year "+year+" is a leap year");
	        else
	          System.out.println("year "+year+" is not a leap year");
	    }
}
