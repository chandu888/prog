CREATE TABLE empl(
name varchar2(255) not null,
Password varchar2(255) not null,
gender varchar2(255) not null,
city varchar2(255) not null,
experience varchar2(255) not null,
technology varchar2(255) not null
);


insert into empl values('ravi','king','male','chennai','2','java');
select * from empl;
