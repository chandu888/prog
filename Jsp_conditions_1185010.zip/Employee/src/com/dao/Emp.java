package com.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import com.beans.StudentDetails;

public class Emp {

	static Connection conn=null;
	static PreparedStatement pstm=null;
	static ResultSet rs=null;
	
	public static  boolean checkUser(String name,String paswrd) throws SQLException, ClassNotFoundException {
		
		boolean check=false;
		
		try{
			conn=DbUtil.getConnection();
			String query="select * from empl";
			pstm=conn.prepareStatement(query);
			rs=pstm.executeQuery();
			
			
			while(rs.next())
			{
				if(name.equals(rs.getString(1)) && paswrd.equals(rs.getString(2)))
				{
					check=true;
					
				}
				System.out.println(check);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
				DbUtil.closeConnection(conn);
				DbUtil.closePrepared(pstm);
				DbUtil.closeResult(rs);			
		}

		return check;
	}
	
	public static int addDetails(StudentDetails details) throws SQLException,ClassNotFoundException{
		
		int check=0;
		try{
			
			conn=DbUtil.getConnection();
			String query="insert into empl values(?,?,?,?,?,?)";
			pstm=conn.prepareStatement(query);
			pstm.setString(1, details.getName());
			pstm.setString(2, details.getPassword());
			pstm.setString(3, details.getGender());
			pstm.setString(4, details.getCity());
			pstm.setString(5, details.getExperience());
			pstm.setString(6, details.getTech());
			check=pstm.executeUpdate();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		finally
		{
				DbUtil.closeConnection(conn);
				DbUtil.closePrepared(pstm);
				DbUtil.closeResult(rs);			
		}
		return check;
	}
	
	
	public static ArrayList<StudentDetails> viewAll() throws SQLException,ClassNotFoundException{
		
		ArrayList<StudentDetails> studentList=new ArrayList<StudentDetails>();
		
		try{
			conn=DbUtil.getConnection();
			String query="select * from empl";
			pstm=conn.prepareStatement(query);
			rs=pstm.executeQuery();
			
			while(rs.next()){
				studentList.add(new StudentDetails(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6)));
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		finally
		{
				DbUtil.closeConnection(conn);
				DbUtil.closePrepared(pstm);
				DbUtil.closeResult(rs);			
		}
		return studentList;
	}
}
