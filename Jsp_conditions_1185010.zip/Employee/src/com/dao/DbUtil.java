package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DbUtil {

	static Connection conn=null;
	static PreparedStatement pstm=null;
	static ResultSet rs=null;
	
	private static final String driver="oracle.jdbc.driver.OracleDriver";
	private static final String url="jdbc:oracle:thin:@inchnilpdb03.India.TCS.com:1521:JavaDB03";
	private static final String username="E1185010";
	private static final String password="E1185010";
	 
	public static Connection getConnection() throws SQLException,ClassNotFoundException{
		try{
		Class.forName(driver);
		conn=DriverManager.getConnection(url,username,password);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return conn;
	}
	public static void closePrepared(PreparedStatement pstmt) throws SQLException,ClassNotFoundException{
		try{
			if(pstmt != null)
				pstmt.close();
		}
		catch (SQLException e){
			e.printStackTrace();
		}		
	}
	public static void closeResult(ResultSet rs) throws SQLException,ClassNotFoundException{
		try{
			if(rs != null)
				rs.close();
		}
		catch(SQLException e){
			e.printStackTrace();
		}
	}
	public static void closeConnection(Connection con) throws SQLException,ClassNotFoundException{
		try{
			if(con != null)
				con.close();
		}
		catch(SQLException e){
			e.printStackTrace();
		}
	}

}
