package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.*;
import com.beans.StudentDetails;


public class MyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MyServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String name=request.getParameter("name");
		String pass=request.getParameter("password1");
        PrintWriter out=response.getWriter();
		
		try{
			
		if(request.getParameter("action").equals("login"))
		{
			boolean i=Emp.checkUser(name,pass);
			
			if(i) 
			{
				RequestDispatcher dr=request.getRequestDispatcher("viewpage.jsp");
				dr.forward(request, response);
			}
			
			else{
				
				RequestDispatcher dr=request.getRequestDispatcher("viewepage.jsp");
				dr.forward(request, response);
			}
		}
		
		else if (request.getParameter("action").equals("register"))
		{
			
			StudentDetails details=new StudentDetails();
			details.setName(request.getParameter("name"));
			details.setPassword(request.getParameter("password1"));
			details.setGender(request.getParameter("gender"));
			details.setCity(request.getParameter("city"));
			details.setExperience(request.getParameter("experience"));
			details.setTech(request.getParameter("technology"));
				
			
					int i=Emp.addDetails(details);
					
					if(i>=1)
					{
						RequestDispatcher dr=request.getRequestDispatcher("added.jsp");
						dr.forward(request, response);
					}
					
					else
					{
						out.println("details not added");
					}
			
			} 
		
		}
		catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	}

}
